import { Heart } from 'lucide-react';
import { useNavigate } from 'react-router';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';

export function Login() {
  const navigate = useNavigate();

  const handleLogin = () => {
    navigate('/dashboard');
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-6 bg-gradient-to-br from-purple-50 via-pink-50 to-white">
      <div className="w-full max-w-md">
        {/* Logo */}
        <div className="flex justify-center mb-6">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-purple-400 to-pink-400 flex items-center justify-center">
            <Heart className="w-8 h-8 text-white fill-white" />
          </div>
        </div>

        {/* Title */}
        <h1 className="text-3xl text-center mb-2">Welcome to SAKHI+</h1>
        <p className="text-center text-muted-foreground mb-8">
          Sign in to continue your journey
        </p>

        {/* Login Form */}
        <div className="bg-white rounded-3xl p-6 shadow-lg border border-border">
          <div className="space-y-4">
            <div>
              <Label htmlFor="email">Email / Phone</Label>
              <Input
                id="email"
                type="text"
                placeholder="Enter your email or phone"
                className="mt-1.5 rounded-xl border-border bg-input-background"
              />
            </div>

            <div>
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                type="password"
                placeholder="Enter your password"
                className="mt-1.5 rounded-xl border-border bg-input-background"
              />
            </div>

            <Button
              onClick={handleLogin}
              className="w-full h-12 rounded-xl bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white"
            >
              Login
            </Button>

            <div className="text-center">
              <button
                onClick={() => navigate('/dashboard')}
                className="text-sm text-primary hover:underline"
              >
                New here? Sign up
              </button>
            </div>

            <div className="text-center">
              <button
                onClick={() => navigate('/dashboard')}
                className="text-sm text-muted-foreground hover:text-foreground"
              >
                Continue as Guest
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
