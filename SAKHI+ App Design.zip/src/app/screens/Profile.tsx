import { Heart, User, Settings, Bell, HelpCircle, Shield, LogOut } from 'lucide-react';
import { useNavigate } from 'react-router';
import { BottomNavigation } from '../components/BottomNavigation';

export function Profile() {
  const navigate = useNavigate();

  const menuItems = [
    { icon: User, label: 'Edit Profile', path: '#' },
    { icon: Settings, label: 'Settings', path: '#' },
    { icon: Bell, label: 'Notifications', path: '#' },
    { icon: Shield, label: 'Privacy & Security', path: '#' },
    { icon: HelpCircle, label: 'Help & Support', path: '#' },
  ];

  return (
    <div className="min-h-screen pb-20 bg-gradient-to-br from-purple-50/50 via-pink-50/50 to-white">
      {/* Header */}
      <div className="bg-white border-b border-border">
        <div className="max-w-lg mx-auto px-6 py-6">
          <h1 className="text-2xl">Profile</h1>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-lg mx-auto px-6 py-6 space-y-5">
        {/* User Info */}
        <div className="bg-white rounded-2xl p-6 shadow-sm border border-border text-center">
          <div className="w-20 h-20 mx-auto mb-4 rounded-full bg-gradient-to-br from-purple-400 to-pink-400 flex items-center justify-center">
            <User className="w-10 h-10 text-white" />
          </div>
          <h2 className="text-xl mb-1">Welcome</h2>
          <p className="text-sm text-muted-foreground mb-4">user@example.com</p>
          
          <div className="grid grid-cols-3 gap-4 pt-4 border-t border-border">
            <div>
              <p className="text-2xl mb-1 bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">12</p>
              <p className="text-xs text-muted-foreground">Posts</p>
            </div>
            <div>
              <p className="text-2xl mb-1 bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">5</p>
              <p className="text-xs text-muted-foreground">Streak</p>
            </div>
            <div>
              <p className="text-2xl mb-1 bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">28</p>
              <p className="text-xs text-muted-foreground">Support</p>
            </div>
          </div>
        </div>

        {/* Menu Items */}
        <div className="bg-white rounded-2xl shadow-sm border border-border overflow-hidden">
          {menuItems.map((item, index) => {
            const Icon = item.icon;
            return (
              <button
                key={index}
                className={`w-full flex items-center gap-4 p-4 hover:bg-secondary transition-colors ${
                  index !== menuItems.length - 1 ? 'border-b border-border' : ''
                }`}
              >
                <div className="w-10 h-10 rounded-xl bg-secondary flex items-center justify-center">
                  <Icon className="w-5 h-5 text-primary" />
                </div>
                <span className="flex-1 text-left">{item.label}</span>
                <svg
                  className="w-5 h-5 text-muted-foreground"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M9 5l7 7-7 7"
                  />
                </svg>
              </button>
            );
          })}
        </div>

        {/* About SAKHI+ */}
        <div className="bg-white rounded-2xl p-5 shadow-sm border border-border">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-400 to-pink-400 flex items-center justify-center">
              <Heart className="w-5 h-5 text-white fill-white" />
            </div>
            <h3>About SAKHI+</h3>
          </div>
          <p className="text-sm text-muted-foreground leading-relaxed">
            Your trusted digital companion for health, safety, and personal growth. 
            We're here to support you every step of the way.
          </p>
          <div className="flex gap-3 mt-4 text-xs text-muted-foreground">
            <span>Version 1.0.0</span>
            <span>•</span>
            <button className="hover:text-primary">Terms</button>
            <span>•</span>
            <button className="hover:text-primary">Privacy</button>
          </div>
        </div>

        {/* Logout Button */}
        <button
          onClick={() => navigate('/')}
          className="w-full flex items-center justify-center gap-2 p-4 rounded-2xl bg-red-50 text-red-600 hover:bg-red-100 transition-colors"
        >
          <LogOut className="w-5 h-5" />
          <span>Log Out</span>
        </button>
      </div>

      <BottomNavigation />
    </div>
  );
}
