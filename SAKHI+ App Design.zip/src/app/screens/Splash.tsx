import { Heart } from 'lucide-react';
import { useNavigate } from 'react-router';
import { Button } from '../components/ui/button';

export function Splash() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-6 bg-gradient-to-br from-purple-50 via-pink-50 to-white">
      <div className="flex flex-col items-center gap-8 max-w-md mx-auto text-center">
        {/* Logo */}
        <div className="relative">
          <div className="w-24 h-24 rounded-3xl bg-gradient-to-br from-purple-400 to-pink-400 flex items-center justify-center shadow-lg">
            <Heart className="w-12 h-12 text-white fill-white" />
          </div>
        </div>

        {/* App Name */}
        <div>
          <h1 className="text-5xl mb-3 bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
            SAKHI+
          </h1>
          <p className="text-lg text-foreground/80 leading-relaxed">
            Your digital companion for health, safety & growth
          </p>
        </div>

        {/* Get Started Button */}
        <Button
          onClick={() => navigate('/login')}
          className="w-full max-w-xs h-12 rounded-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white shadow-lg"
        >
          Get Started
        </Button>

        {/* Tagline */}
        <div className="flex gap-3 text-sm text-muted-foreground">
          <span>Inclusive</span>
          <span>•</span>
          <span>Secure</span>
          <span>•</span>
          <span>Supportive</span>
        </div>
      </div>
    </div>
  );
}
