import { ArrowLeft, Smile, Meh, Frown, Angry, Brain } from 'lucide-react';
import { useNavigate } from 'react-router';
import { BottomNavigation } from '../components/BottomNavigation';
import { useState } from 'react';

export function Mood() {
  const navigate = useNavigate();
  const [selectedMood, setSelectedMood] = useState<string | null>(null);

  const moods = [
    { id: 'happy', label: 'Happy', icon: '😊', color: 'from-yellow-400 to-amber-400' },
    { id: 'okay', label: 'Okay', icon: '😐', color: 'from-blue-400 to-cyan-400' },
    { id: 'low', label: 'Low', icon: '😔', color: 'from-gray-400 to-slate-400' },
    { id: 'anxious', label: 'Anxious', icon: '😟', color: 'from-orange-400 to-red-400' },
  ];

  const getAIResponse = (mood: string) => {
    const responses: { [key: string]: { message: string; suggestions: string[] } } = {
      happy: {
        message: "That's wonderful! Keep up the positive energy.",
        suggestions: [
          '🎉 Share your joy with others',
          '✍️ Journal about what made you happy',
          '🎯 Set a new positive goal',
        ],
      },
      okay: {
        message: "It's perfectly fine to feel just okay.",
        suggestions: [
          '🚶‍♀️ Take a gentle walk',
          '☕ Enjoy a moment of self-care',
          '📖 Read something inspiring',
        ],
      },
      low: {
        message: "It's okay to feel this way. Remember, this is temporary.",
        suggestions: [
          '🧘‍♀️ Try a short meditation',
          '💬 Talk to someone you trust',
          '🎵 Listen to uplifting music',
        ],
      },
      anxious: {
        message: "It's okay to feel anxious. Try some calming techniques.",
        suggestions: [
          '🫁 Try deep breathing exercises',
          '📝 Write down your worries',
          '🧠 Practice mindfulness',
        ],
      },
    };
    return responses[mood] || responses.okay;
  };

  return (
    <div className="min-h-screen pb-20 bg-gradient-to-br from-purple-50/50 via-pink-50/50 to-white">
      {/* Header */}
      <div className="bg-white border-b border-border">
        <div className="max-w-lg mx-auto px-6 py-4">
          <div className="flex items-center gap-3">
            <button
              onClick={() => navigate('/dashboard')}
              className="w-10 h-10 rounded-xl bg-secondary hover:bg-secondary/80 flex items-center justify-center"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div>
              <h1 className="text-xl flex items-center gap-2">
                <Smile className="w-5 h-5 text-yellow-500" />
                Mood Check-In
              </h1>
              <p className="text-sm text-muted-foreground">How are you feeling today?</p>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-lg mx-auto px-6 py-8 space-y-6">
        {/* Question */}
        <div className="text-center">
          <h2 className="text-2xl mb-2">How are you feeling today?</h2>
          <p className="text-muted-foreground">Select the mood that best describes you</p>
        </div>

        {/* Mood Buttons */}
        <div className="grid grid-cols-2 gap-4">
          {moods.map((mood) => (
            <button
              key={mood.id}
              onClick={() => setSelectedMood(mood.id)}
              className={`p-6 rounded-2xl border-2 transition-all ${
                selectedMood === mood.id
                  ? `border-primary bg-gradient-to-br ${mood.color} text-white shadow-lg scale-105`
                  : 'border-border bg-white hover:border-primary/50 hover:shadow-md'
              }`}
            >
              <div className="text-4xl mb-3">{mood.icon}</div>
              <p className={`text-lg ${selectedMood === mood.id ? 'text-white' : ''}`}>
                {mood.label}
              </p>
            </button>
          ))}
        </div>

        {/* AI Response */}
        {selectedMood && (
          <div className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-2xl p-6 border border-purple-200 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-purple-400 to-indigo-400 flex items-center justify-center">
                <Brain className="w-6 h-6 text-white" />
              </div>
              <div>
                <h3 className="text-purple-900">AI Wellness Support</h3>
                <p className="text-sm text-purple-800">Personalized for you</p>
              </div>
            </div>

            <div className="bg-white rounded-xl p-4 mb-4 border border-purple-200">
              <p className="text-sm text-purple-900 leading-relaxed">
                {getAIResponse(selectedMood).message}
              </p>
            </div>

            <div className="space-y-2">
              <p className="text-sm text-purple-900 mb-3">Try these activities:</p>
              {getAIResponse(selectedMood).suggestions.map((suggestion, index) => (
                <div
                  key={index}
                  className="bg-white rounded-xl p-3 border border-purple-200"
                >
                  <p className="text-sm text-purple-800">{suggestion}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Mood History */}
        <div className="bg-white rounded-2xl p-5 shadow-sm border border-border">
          <h3 className="mb-4">Your Mood This Week</h3>
          
          <div className="space-y-3">
            {['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'].map((day, index) => (
              <div key={day} className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">{day}</span>
                <div className="flex gap-2">
                  {index === 0 && <span className="text-lg">😊</span>}
                  {index === 1 && <span className="text-lg">😐</span>}
                  {index === 2 && <span className="text-lg">😔</span>}
                  {index === 3 && <span className="text-lg">😊</span>}
                  {index === 4 && <span className="text-lg">😟</span>}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Resources */}
        <div className="bg-white rounded-2xl p-5 shadow-sm border border-border">
          <h3 className="mb-4">Mental Wellness Resources</h3>
          
          <div className="space-y-2">
            <button className="w-full p-3 rounded-xl bg-muted hover:bg-muted/80 text-left text-sm">
              🧘‍♀️ Guided Meditation (10 min)
            </button>
            <button className="w-full p-3 rounded-xl bg-muted hover:bg-muted/80 text-left text-sm">
              📖 Journaling Prompts
            </button>
            <button className="w-full p-3 rounded-xl bg-muted hover:bg-muted/80 text-left text-sm">
              💬 Talk to a Support Group
            </button>
            <button className="w-full p-3 rounded-xl bg-muted hover:bg-muted/80 text-left text-sm">
              📞 Mental Health Helpline
            </button>
          </div>
        </div>
      </div>

      <BottomNavigation />
    </div>
  );
}
