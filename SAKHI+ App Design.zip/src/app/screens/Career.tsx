import { ArrowLeft, GraduationCap, Briefcase, FileText, Lightbulb, Users, Bot } from 'lucide-react';
import { useNavigate } from 'react-router';
import { BottomNavigation } from '../components/BottomNavigation';

export function Career() {
  const navigate = useNavigate();

  const courses = [
    { title: 'UI/UX Design Fundamentals', duration: '6 weeks', level: 'Beginner' },
    { title: 'Data Analysis with Python', duration: '8 weeks', level: 'Intermediate' },
    { title: 'Digital Marketing', duration: '4 weeks', level: 'Beginner' },
  ];

  return (
    <div className="min-h-screen pb-20 bg-gradient-to-br from-purple-50/50 via-pink-50/50 to-white">
      {/* Header */}
      <div className="bg-white border-b border-border">
        <div className="max-w-lg mx-auto px-6 py-4">
          <div className="flex items-center gap-3">
            <button
              onClick={() => navigate('/dashboard')}
              className="w-10 h-10 rounded-xl bg-secondary hover:bg-secondary/80 flex items-center justify-center"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div>
              <h1 className="text-xl flex items-center gap-2">
                <GraduationCap className="w-5 h-5 text-blue-500" />
                Career & Education
              </h1>
              <p className="text-sm text-muted-foreground">Grow your professional journey</p>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-lg mx-auto px-6 py-6 space-y-5">
        {/* Find a Mentor */}
        <div className="bg-white rounded-2xl p-5 shadow-sm border border-border">
          <div className="flex items-start gap-3 mb-4">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-purple-400 to-pink-400 flex items-center justify-center">
              <Users className="w-6 h-6 text-white" />
            </div>
            <div className="flex-1">
              <h3 className="mb-1">Find a Mentor</h3>
              <p className="text-sm text-muted-foreground">Connect with experienced professionals</p>
            </div>
          </div>
          
          <div className="space-y-3">
            <div className="p-3 rounded-xl bg-gradient-to-r from-purple-50 to-pink-50 border border-purple-200">
              <div className="flex items-start justify-between mb-2">
                <div>
                  <p className="text-sm mb-1">👩‍💼 Tech Industry</p>
                  <p className="text-xs text-muted-foreground">50+ mentors available</p>
                </div>
                <button className="px-3 py-1 rounded-lg bg-gradient-to-r from-purple-500 to-pink-500 text-white text-xs">
                  Browse
                </button>
              </div>
            </div>
            <div className="p-3 rounded-xl bg-gradient-to-r from-blue-50 to-cyan-50 border border-blue-200">
              <div className="flex items-start justify-between mb-2">
                <div>
                  <p className="text-sm mb-1">💼 Business & Finance</p>
                  <p className="text-xs text-muted-foreground">35+ mentors available</p>
                </div>
                <button className="px-3 py-1 rounded-lg bg-gradient-to-r from-blue-500 to-cyan-500 text-white text-xs">
                  Browse
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Online Courses */}
        <div className="bg-white rounded-2xl p-5 shadow-sm border border-border">
          <div className="flex items-start gap-3 mb-4">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-400 to-cyan-400 flex items-center justify-center">
              <GraduationCap className="w-6 h-6 text-white" />
            </div>
            <div className="flex-1">
              <h3 className="mb-1">Online Courses</h3>
              <p className="text-sm text-muted-foreground">Free and paid learning resources</p>
            </div>
          </div>
          
          <div className="space-y-3">
            {courses.map((course, index) => (
              <div key={index} className="p-3 rounded-xl bg-muted hover:bg-muted/80 transition-colors">
                <p className="text-sm mb-2">{course.title}</p>
                <div className="flex gap-3 text-xs text-muted-foreground">
                  <span>⏱️ {course.duration}</span>
                  <span>•</span>
                  <span>📊 {course.level}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Resume Tips */}
        <div className="bg-white rounded-2xl p-5 shadow-sm border border-border">
          <div className="flex items-start gap-3 mb-4">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-green-400 to-emerald-400 flex items-center justify-center">
              <FileText className="w-6 h-6 text-white" />
            </div>
            <div className="flex-1">
              <h3 className="mb-1">Resume Tips</h3>
              <p className="text-sm text-muted-foreground">Build a standout resume</p>
            </div>
          </div>
          
          <div className="space-y-2">
            <button className="w-full p-3 rounded-xl bg-muted hover:bg-muted/80 text-left text-sm">
              📝 Resume Templates
            </button>
            <button className="w-full p-3 rounded-xl bg-muted hover:bg-muted/80 text-left text-sm">
              ✍️ Cover Letter Guide
            </button>
            <button className="w-full p-3 rounded-xl bg-muted hover:bg-muted/80 text-left text-sm">
              🎯 Interview Preparation
            </button>
          </div>
        </div>

        {/* AI Career Guidance */}
        <div className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-2xl p-5 border border-purple-200">
          <div className="flex items-start gap-3 mb-4">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-purple-400 to-indigo-400 flex items-center justify-center">
              <Bot className="w-6 h-6 text-white" />
            </div>
            <div className="flex-1">
              <h3 className="text-purple-900 mb-1">AI Career Guidance</h3>
              <p className="text-sm text-purple-800">Personalized career recommendations</p>
            </div>
          </div>
          
          <div className="bg-white rounded-xl p-4 border border-purple-200 mb-3">
            <p className="text-sm text-purple-900 mb-2">🤖 AI Suggestion:</p>
            <p className="text-sm text-purple-800 leading-relaxed">
              "Based on your interest in technology and creativity, consider exploring UI/UX design or data analysis. Both fields offer excellent growth opportunities and remote work options."
            </p>
          </div>

          <button className="w-full py-3 rounded-xl bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white text-sm">
            Get Personalized Guidance
          </button>
        </div>

        {/* Job Board Preview */}
        <div className="bg-white rounded-2xl p-5 shadow-sm border border-border">
          <div className="flex items-start gap-3 mb-4">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-orange-400 to-red-400 flex items-center justify-center">
              <Briefcase className="w-6 h-6 text-white" />
            </div>
            <div className="flex-1">
              <h3 className="mb-1">Job Opportunities</h3>
              <p className="text-sm text-muted-foreground">Women-friendly workplaces</p>
            </div>
          </div>
          
          <div className="space-y-3">
            <div className="p-3 rounded-xl border border-border">
              <p className="text-sm mb-1">Senior Designer</p>
              <p className="text-xs text-muted-foreground mb-2">Remote • Full-time</p>
              <div className="flex gap-2">
                <span className="px-2 py-1 rounded-md bg-green-100 text-green-800 text-xs">Flexible Hours</span>
                <span className="px-2 py-1 rounded-md bg-purple-100 text-purple-800 text-xs">Inclusive</span>
              </div>
            </div>
            <div className="p-3 rounded-xl border border-border">
              <p className="text-sm mb-1">Data Analyst</p>
              <p className="text-xs text-muted-foreground mb-2">Hybrid • Full-time</p>
              <div className="flex gap-2">
                <span className="px-2 py-1 rounded-md bg-green-100 text-green-800 text-xs">Parental Leave</span>
                <span className="px-2 py-1 rounded-md bg-purple-100 text-purple-800 text-xs">Diverse Team</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <BottomNavigation />
    </div>
  );
}
