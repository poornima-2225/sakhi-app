import { Heart, Bot, AlertCircle, GraduationCap, Users, Smile, Activity, Shield } from 'lucide-react';
import { useNavigate } from 'react-router';
import { BottomNavigation } from '../components/BottomNavigation';

export function Dashboard() {
  const navigate = useNavigate();

  const features = [
    {
      id: 'health',
      title: 'Health Hub',
      subtitle: 'Menstrual • Mental • Wellness',
      icon: Activity,
      color: 'from-pink-400 to-rose-400',
      path: '/health-hub',
    },
    {
      id: 'ai',
      title: 'AI Health Assistant',
      subtitle: 'Ask health-related questions',
      icon: Bot,
      color: 'from-purple-400 to-indigo-400',
      path: '/ai-assistant',
    },
    {
      id: 'sos',
      title: 'Safety & SOS',
      subtitle: 'Emergency help & legal support',
      icon: Shield,
      color: 'from-red-400 to-orange-400',
      path: '/sos',
    },
    {
      id: 'career',
      title: 'Career & Education',
      subtitle: 'Mentors • Jobs • Skills',
      icon: GraduationCap,
      color: 'from-blue-400 to-cyan-400',
      path: '/career',
    },
    {
      id: 'community',
      title: 'Community',
      subtitle: 'Share • Support • Connect',
      icon: Users,
      color: 'from-green-400 to-emerald-400',
      path: '/community',
    },
    {
      id: 'mood',
      title: 'Mood Check-In',
      subtitle: 'Mental wellness support',
      icon: Smile,
      color: 'from-yellow-400 to-amber-400',
      path: '/mood',
    },
  ];

  return (
    <div className="min-h-screen pb-20 bg-gradient-to-br from-purple-50/50 via-pink-50/50 to-white">
      {/* Header */}
      <div className="bg-white border-b border-border">
        <div className="max-w-lg mx-auto px-6 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl flex items-center gap-2">
                Hello 👋
              </h1>
              <p className="text-muted-foreground mt-1">
                How can we support you today?
              </p>
            </div>
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-purple-400 to-pink-400 flex items-center justify-center">
              <Heart className="w-6 h-6 text-white fill-white" />
            </div>
          </div>
        </div>
      </div>

      {/* Feature Cards Grid */}
      <div className="max-w-lg mx-auto px-6 py-6">
        <div className="grid grid-cols-2 gap-4">
          {features.map((feature) => {
            const Icon = feature.icon;
            return (
              <button
                key={feature.id}
                onClick={() => navigate(feature.path)}
                className="bg-white rounded-2xl p-5 shadow-sm border border-border hover:shadow-md transition-shadow text-left"
              >
                <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${feature.color} flex items-center justify-center mb-3`}>
                  <Icon className="w-6 h-6 text-white" />
                </div>
                <h3 className="mb-1">{feature.title}</h3>
                <p className="text-sm text-muted-foreground leading-snug">
                  {feature.subtitle}
                </p>
              </button>
            );
          })}
        </div>
      </div>

      <BottomNavigation />
    </div>
  );
}
