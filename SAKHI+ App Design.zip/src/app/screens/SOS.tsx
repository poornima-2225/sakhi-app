import { ArrowLeft, AlertCircle, Phone, FileText, MapPin, Shield } from 'lucide-react';
import { useNavigate } from 'react-router';
import { Button } from '../components/ui/button';
import { BottomNavigation } from '../components/BottomNavigation';
import { useState } from 'react';

export function SOS() {
  const navigate = useNavigate();
  const [selectedScenario, setSelectedScenario] = useState<string | null>(null);

  const scenarios = [
    { id: 'followed', label: 'Being followed' },
    { id: 'harassment', label: 'Workplace harassment' },
    { id: 'domestic', label: 'Domestic violence' },
  ];

  const helplines = [
    { name: 'Women Helpline', number: '1091' },
    { name: 'Police Emergency', number: '100' },
    { name: 'Domestic Abuse', number: '181' },
  ];

  const getAISuggestion = (scenario: string) => {
    const suggestions: { [key: string]: string } = {
      followed: 'Move to a public place immediately, contact emergency services, and reach out to trusted contacts. Stay in well-lit areas.',
      harassment: 'Document all incidents, inform HR or supervisor, and contact legal support. Your safety and rights are protected by law.',
      domestic: 'Contact emergency services immediately. Reach out to domestic violence helpline and consider a safe place to stay.',
    };
    return suggestions[scenario] || '';
  };

  return (
    <div className="min-h-screen pb-20 bg-gradient-to-br from-purple-50/50 via-pink-50/50 to-white">
      {/* Header */}
      <div className="bg-white border-b border-border">
        <div className="max-w-lg mx-auto px-6 py-4">
          <div className="flex items-center gap-3">
            <button
              onClick={() => navigate('/dashboard')}
              className="w-10 h-10 rounded-xl bg-secondary hover:bg-secondary/80 flex items-center justify-center"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div>
              <h1 className="text-xl flex items-center gap-2">
                <Shield className="w-5 h-5 text-red-500" />
                Safety & SOS
              </h1>
              <p className="text-sm text-muted-foreground">Emergency support & resources</p>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-lg mx-auto px-6 py-6 space-y-5">
        {/* SOS Button */}
        <div className="bg-white rounded-2xl p-6 shadow-sm border border-border">
          <Button className="w-full h-16 rounded-2xl bg-gradient-to-r from-red-500 to-orange-500 hover:from-red-600 hover:to-orange-600 text-white text-lg shadow-lg">
            <AlertCircle className="w-6 h-6 mr-2" />
            SOS – Get Help Now
          </Button>
          <p className="text-xs text-center text-muted-foreground mt-3">
            Emergency services will be contacted immediately
          </p>
        </div>

        {/* Emergency Helplines */}
        <div className="bg-white rounded-2xl p-5 shadow-sm border border-border">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-red-400 to-orange-400 flex items-center justify-center">
              <Phone className="w-6 h-6 text-white" />
            </div>
            <h3>Emergency Helplines</h3>
          </div>
          
          <div className="space-y-3">
            {helplines.map((helpline, index) => (
              <div
                key={index}
                className="flex items-center justify-between p-3 rounded-xl bg-muted"
              >
                <span className="text-sm">{helpline.name}</span>
                <button className="px-4 py-2 rounded-lg bg-red-500 text-white text-sm hover:bg-red-600">
                  {helpline.number}
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Legal Rights */}
        <div className="bg-white rounded-2xl p-5 shadow-sm border border-border">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-400 to-indigo-400 flex items-center justify-center">
              <FileText className="w-6 h-6 text-white" />
            </div>
            <h3>Legal Rights Info</h3>
          </div>
          
          <div className="space-y-2">
            <button className="w-full p-3 rounded-xl bg-muted hover:bg-muted/80 text-left text-sm">
              📋 Workplace Rights & Laws
            </button>
            <button className="w-full p-3 rounded-xl bg-muted hover:bg-muted/80 text-left text-sm">
              🏛️ Legal Aid Resources
            </button>
            <button className="w-full p-3 rounded-xl bg-muted hover:bg-muted/80 text-left text-sm">
              📱 Report Harassment
            </button>
          </div>
        </div>

        {/* Share Location */}
        <div className="bg-white rounded-2xl p-5 shadow-sm border border-border">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-green-400 to-emerald-400 flex items-center justify-center">
              <MapPin className="w-6 h-6 text-white" />
            </div>
            <div className="flex-1">
              <h3>Share Location</h3>
              <p className="text-sm text-muted-foreground">With trusted contacts</p>
            </div>
          </div>
          <Button className="w-full rounded-xl border border-border hover:bg-secondary">
            Share My Location
          </Button>
        </div>

        {/* AI Safety Advisor */}
        <div className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-2xl p-5 border border-purple-200">
          <div className="flex items-center gap-2 mb-4">
            <Shield className="w-5 h-5 text-purple-600" />
            <h3 className="text-purple-900">AI Safety Advisor</h3>
          </div>
          
          <p className="text-sm text-purple-800 mb-4">Select your situation for immediate guidance:</p>
          
          <div className="space-y-2 mb-4">
            {scenarios.map((scenario) => (
              <button
                key={scenario.id}
                onClick={() => setSelectedScenario(scenario.id)}
                className={`w-full p-3 rounded-xl text-sm text-left transition-colors ${
                  selectedScenario === scenario.id
                    ? 'bg-purple-500 text-white'
                    : 'bg-white border border-purple-200 hover:bg-purple-50 text-purple-900'
                }`}
              >
                {scenario.label}
              </button>
            ))}
          </div>

          {selectedScenario && (
            <div className="bg-white rounded-xl p-4 border border-purple-200">
              <p className="text-sm text-purple-900 mb-2">🤖 AI Recommendation:</p>
              <p className="text-sm text-purple-800 leading-relaxed">
                {getAISuggestion(selectedScenario)}
              </p>
            </div>
          )}
        </div>
      </div>

      <BottomNavigation />
    </div>
  );
}
