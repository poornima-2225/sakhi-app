import { ArrowLeft, Users, Heart, MessageCircle, Shield } from 'lucide-react';
import { useNavigate } from 'react-router';
import { BottomNavigation } from '../components/BottomNavigation';
import { Button } from '../components/ui/button';

export function Community() {
  const navigate = useNavigate();

  const categories = ['Health', 'Career', 'Mental Wellness', 'Safety'];

  const posts = [
    {
      id: 1,
      category: 'Mental Wellness',
      user: 'Anonymous User',
      time: '2h ago',
      content: 'How do you handle work stress? I\'ve been feeling overwhelmed lately and would love to hear your tips.',
      replies: 12,
      supports: 24,
    },
    {
      id: 2,
      category: 'Career',
      user: 'Anonymous User',
      time: '5h ago',
      content: 'Just got my first job offer! Thank you all for the resume tips and interview advice. This community is amazing! 💜',
      replies: 8,
      supports: 45,
    },
    {
      id: 3,
      category: 'Health',
      user: 'Anonymous User',
      time: '1d ago',
      content: 'What are your go-to self-care routines during your period? Looking for natural remedies.',
      replies: 18,
      supports: 31,
    },
  ];

  return (
    <div className="min-h-screen pb-20 bg-gradient-to-br from-purple-50/50 via-pink-50/50 to-white">
      {/* Header */}
      <div className="bg-white border-b border-border">
        <div className="max-w-lg mx-auto px-6 py-4">
          <div className="flex items-center gap-3">
            <button
              onClick={() => navigate('/dashboard')}
              className="w-10 h-10 rounded-xl bg-secondary hover:bg-secondary/80 flex items-center justify-center"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div className="flex-1">
              <h1 className="text-xl flex items-center gap-2">
                <Users className="w-5 h-5 text-green-500" />
                Community
              </h1>
              <p className="text-sm text-muted-foreground">Share • Support • Connect</p>
            </div>
            <Button className="rounded-xl bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white">
              + New Post
            </Button>
          </div>
        </div>
      </div>

      {/* Categories */}
      <div className="max-w-lg mx-auto px-6 py-4">
        <div className="flex gap-2 overflow-x-auto pb-2">
          <button className="px-4 py-2 rounded-full bg-gradient-to-r from-purple-500 to-pink-500 text-white text-sm whitespace-nowrap">
            All
          </button>
          {categories.map((category, index) => (
            <button
              key={index}
              className="px-4 py-2 rounded-full bg-white border border-border text-sm whitespace-nowrap hover:bg-secondary"
            >
              {category}
            </button>
          ))}
        </div>
      </div>

      {/* Posts */}
      <div className="max-w-lg mx-auto px-6 space-y-4 pb-6">
        {posts.map((post) => (
          <div key={post.id} className="bg-white rounded-2xl p-5 shadow-sm border border-border">
            <div className="flex items-start justify-between mb-3">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <div className="w-8 h-8 rounded-full bg-gradient-to-br from-purple-400 to-pink-400 flex items-center justify-center">
                    <Users className="w-4 h-4 text-white" />
                  </div>
                  <div>
                    <p className="text-sm">{post.user}</p>
                    <p className="text-xs text-muted-foreground">{post.time}</p>
                  </div>
                </div>
              </div>
              <span className="px-3 py-1 rounded-full bg-secondary text-xs">
                {post.category}
              </span>
            </div>

            <p className="text-sm leading-relaxed mb-4">{post.content}</p>

            <div className="flex items-center gap-4 pt-3 border-t border-border">
              <button className="flex items-center gap-2 text-sm text-muted-foreground hover:text-primary transition-colors">
                <MessageCircle className="w-4 h-4" />
                <span>{post.replies} Replies</span>
              </button>
              <button className="flex items-center gap-2 text-sm text-muted-foreground hover:text-red-500 transition-colors">
                <Heart className="w-4 h-4" />
                <span>{post.supports} Support</span>
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Safety Notice */}
      <div className="max-w-lg mx-auto px-6 pb-6">
        <div className="bg-green-50 border border-green-200 rounded-xl p-4">
          <div className="flex items-start gap-3">
            <Shield className="w-5 h-5 text-green-600 mt-0.5" />
            <div>
              <h4 className="text-sm text-green-900 mb-1">Safe Space</h4>
              <p className="text-xs text-green-800">
                This community is moderated, safe, and inclusive. All posts are anonymous and respectful dialogue is encouraged.
              </p>
            </div>
          </div>
        </div>
      </div>

      <BottomNavigation />
    </div>
  );
}
