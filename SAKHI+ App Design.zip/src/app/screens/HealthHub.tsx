import { ArrowLeft, Calendar, Brain, BookOpen, Activity } from 'lucide-react';
import { useNavigate } from 'react-router';
import { Button } from '../components/ui/button';
import { BottomNavigation } from '../components/BottomNavigation';

export function HealthHub() {
  const navigate = useNavigate();

  const articles = [
    { title: 'Understanding PCOS', category: 'Women\'s Health' },
    { title: 'Managing stress naturally', category: 'Mental Health' },
    { title: 'Pregnancy basics', category: 'Women\'s Health' },
  ];

  return (
    <div className="min-h-screen pb-20 bg-gradient-to-br from-purple-50/50 via-pink-50/50 to-white">
      {/* Header */}
      <div className="bg-white border-b border-border">
        <div className="max-w-lg mx-auto px-6 py-4">
          <div className="flex items-center gap-3">
            <button
              onClick={() => navigate('/dashboard')}
              className="w-10 h-10 rounded-xl bg-secondary hover:bg-secondary/80 flex items-center justify-center"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div>
              <h1 className="text-xl">Women's Health Hub</h1>
              <p className="text-sm text-muted-foreground">Your wellness journey</p>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-lg mx-auto px-6 py-6 space-y-5">
        {/* Menstrual Tracker Card */}
        <div className="bg-white rounded-2xl p-5 shadow-sm border border-border">
          <div className="flex items-start gap-3 mb-4">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-pink-400 to-rose-400 flex items-center justify-center">
              <Activity className="w-6 h-6 text-white" />
            </div>
            <div className="flex-1">
              <h3 className="mb-1">Menstrual Tracker</h3>
              <p className="text-sm text-muted-foreground">Track your cycle & symptoms</p>
            </div>
          </div>
          
          <div className="space-y-3 mb-4">
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Last period date:</span>
              <span>Jan 20, 2026</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Cycle length:</span>
              <span>28 days</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Next expected:</span>
              <span className="text-primary">Feb 17, 2026</span>
            </div>
          </div>
          
          <Button className="w-full rounded-xl bg-gradient-to-r from-pink-500 to-rose-500 hover:from-pink-600 hover:to-rose-600 text-white">
            Track Now
          </Button>
        </div>

        {/* Mental Wellness Card */}
        <div className="bg-white rounded-2xl p-5 shadow-sm border border-border">
          <div className="flex items-start gap-3 mb-4">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-purple-400 to-indigo-400 flex items-center justify-center">
              <Brain className="w-6 h-6 text-white" />
            </div>
            <div className="flex-1">
              <h3 className="mb-1">Mental Wellness</h3>
              <p className="text-sm text-muted-foreground">Mindfulness & stress relief</p>
            </div>
          </div>
          
          <div className="space-y-3">
            <div className="p-3 rounded-xl bg-secondary">
              <p className="text-sm mb-1">💆‍♀️ Stress Management</p>
              <p className="text-xs text-muted-foreground">5 min guided relaxation</p>
            </div>
            <div className="p-3 rounded-xl bg-accent">
              <p className="text-sm mb-1">🧘‍♀️ Breathing Exercise</p>
              <p className="text-xs text-muted-foreground">3 min deep breathing</p>
            </div>
            <div className="p-3 rounded-xl bg-secondary">
              <p className="text-sm mb-1">✨ Daily Affirmation</p>
              <p className="text-xs text-muted-foreground">"I am strong and capable"</p>
            </div>
          </div>
        </div>

        {/* Health Articles Card */}
        <div className="bg-white rounded-2xl p-5 shadow-sm border border-border">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-400 to-cyan-400 flex items-center justify-center">
              <BookOpen className="w-6 h-6 text-white" />
            </div>
            <h3>Health Articles</h3>
          </div>
          
          <div className="space-y-3">
            {articles.map((article, index) => (
              <button
                key={index}
                className="w-full p-3 rounded-xl bg-muted hover:bg-muted/80 text-left transition-colors"
              >
                <p className="text-sm mb-1">{article.title}</p>
                <p className="text-xs text-muted-foreground">{article.category}</p>
              </button>
            ))}
          </div>
        </div>

        {/* Disclaimer */}
        <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 text-center">
          <p className="text-sm text-amber-900">
            ⚠️ Information only. Not medical advice. Please consult a healthcare professional for medical concerns.
          </p>
        </div>
      </div>

      <BottomNavigation />
    </div>
  );
}
