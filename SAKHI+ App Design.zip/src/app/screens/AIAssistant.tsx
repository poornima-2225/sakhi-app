import { ArrowLeft, Bot, Send, Sparkles } from 'lucide-react';
import { useNavigate } from 'react-router';
import { Button } from '../components/ui/button';
import { BottomNavigation } from '../components/BottomNavigation';
import { useState } from 'react';

export function AIAssistant() {
  const navigate = useNavigate();
  const [messages, setMessages] = useState([
    {
      type: 'user',
      text: 'I feel anxious during my periods',
    },
    {
      type: 'ai',
      text: 'This is common. Try breathing exercises, light stretching, and hydration. If symptoms continue, consult a healthcare professional.',
    },
  ]);

  return (
    <div className="min-h-screen pb-32 bg-gradient-to-br from-purple-50/50 via-pink-50/50 to-white">
      {/* Header */}
      <div className="bg-white border-b border-border">
        <div className="max-w-lg mx-auto px-6 py-4">
          <div className="flex items-center gap-3">
            <button
              onClick={() => navigate('/dashboard')}
              className="w-10 h-10 rounded-xl bg-secondary hover:bg-secondary/80 flex items-center justify-center"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div className="flex items-center gap-2 flex-1">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-400 to-indigo-400 flex items-center justify-center">
                <Bot className="w-5 h-5 text-white" />
              </div>
              <div>
                <h1 className="text-xl">AI Health Assistant</h1>
                <p className="text-xs text-muted-foreground flex items-center gap-1">
                  <Sparkles className="w-3 h-3" />
                  AI-powered • Safe • Non-diagnostic
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Chat Messages */}
      <div className="max-w-lg mx-auto px-6 py-6 space-y-4">
        {messages.map((message, index) => (
          <div
            key={index}
            className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div
              className={`max-w-[80%] rounded-2xl p-4 ${
                message.type === 'user'
                  ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-white'
                  : 'bg-white border border-border shadow-sm'
              }`}
            >
              {message.type === 'ai' && (
                <div className="flex items-center gap-2 mb-2">
                  <div className="w-6 h-6 rounded-lg bg-gradient-to-br from-purple-400 to-indigo-400 flex items-center justify-center">
                    <Bot className="w-4 h-4 text-white" />
                  </div>
                  <span className="text-sm text-muted-foreground">AI Assistant</span>
                </div>
              )}
              <p className="text-sm leading-relaxed">{message.text}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Info Card */}
      <div className="max-w-lg mx-auto px-6 pb-6">
        <div className="bg-purple-50 border border-purple-200 rounded-xl p-4">
          <h4 className="text-sm mb-2 text-purple-900 flex items-center gap-2">
            <Sparkles className="w-4 h-4" />
            How I can help
          </h4>
          <ul className="text-xs text-purple-800 space-y-1.5">
            <li>• Answer health-related questions</li>
            <li>• Provide wellness tips and guidance</li>
            <li>• Suggest when to seek professional help</li>
            <li>• Support your mental health journey</li>
          </ul>
        </div>
      </div>

      {/* Input Area */}
      <div className="fixed bottom-16 left-0 right-0 bg-white border-t border-border p-4">
        <div className="max-w-lg mx-auto flex gap-2">
          <input
            type="text"
            placeholder="Ask your health question..."
            className="flex-1 px-4 py-3 rounded-xl bg-input-background border border-border focus:outline-none focus:ring-2 focus:ring-primary/20"
          />
          <Button className="w-12 h-12 rounded-xl bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white flex items-center justify-center p-0">
            <Send className="w-5 h-5" />
          </Button>
        </div>
      </div>

      <BottomNavigation />
    </div>
  );
}
