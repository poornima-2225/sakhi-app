import { createBrowserRouter } from 'react-router';
import { Splash } from './screens/Splash';
import { Login } from './screens/Login';
import { Dashboard } from './screens/Dashboard';
import { HealthHub } from './screens/HealthHub';
import { AIAssistant } from './screens/AIAssistant';
import { SOS } from './screens/SOS';
import { Community } from './screens/Community';
import { Career } from './screens/Career';
import { Mood } from './screens/Mood';
import { Profile } from './screens/Profile';

export const router = createBrowserRouter([
  {
    path: '/',
    Component: Splash,
  },
  {
    path: '/login',
    Component: Login,
  },
  {
    path: '/dashboard',
    Component: Dashboard,
  },
  {
    path: '/health-hub',
    Component: HealthHub,
  },
  {
    path: '/ai-assistant',
    Component: AIAssistant,
  },
  {
    path: '/sos',
    Component: SOS,
  },
  {
    path: '/community',
    Component: Community,
  },
  {
    path: '/career',
    Component: Career,
  },
  {
    path: '/mood',
    Component: Mood,
  },
  {
    path: '/profile',
    Component: Profile,
  },
]);
