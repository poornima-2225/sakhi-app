
  # SAKHI+ App Design

  This is a code bundle for SAKHI+ App Design. The original project is available at https://www.figma.com/design/7KBjb9ViOhCVaRPDo16hZI/SAKHI--App-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  